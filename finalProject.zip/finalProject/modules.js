import aList from "./List.js";

aList.init();

let yourScore = 0;
let theList = [];
let wordNum = 0;
let stillPlaying = true;

// Add instructions
const newParagraph = document.createElement("p");

newParagraph.innerText = "Select the spelling pattern you would like to practice.";

document.getElementById("hero1-box").appendChild(newParagraph)


// Event listener  HTML button with an ID of displayList that calls the display function

const buttonElement = document.getElementById("displayList");
function startGame(event) {
    getList();
    displayWord(0);
}
buttonElement.addEventListener("click", startGame);


function getList() {
    const pattern = document.getElementById("pattern").value;
    console.log("in getlist pattern:", pattern);
    theList = aList.setList(pattern);
    console.log("the list:", theList);
    wordNum = 0;
}

function getWordInfo(num) {
    let numb = parseInt(num);
    let wordInfo = [];
    switch (num) {
        case 0:
            wordInfo = theList.word1;
            break;
        case 1:
            wordInfo = theList.word2; 
            break;
        case 2:
            wordInfo = theList.word3;
            break;           
        case 3:
            wordInfo = theList.word4;
            break;
        case 4:
            wordInfo = theList.word5;
        
    }

    return wordInfo;
    
}



function displayWord(wordNum){
    
    console.log("in displayword:");

    let currentWordInfo = getWordInfo(wordNum);
    console.log(currentWordInfo[0]);

    let word = currentWordInfo[0];
    let clue = currentWordInfo[3];

    //document.getElementById("list").value = word;
    
    document.getElementById("icon-img").src = clue;
    const aWord = document.querySelector("#word");
    aWord.textContent = word;

}

const button2Element = document.getElementById("nextWord");
button2Element.addEventListener("click", nextWord); 


function nextWord() {
   
        let wordGuess = document.getElementById("word1").value;
        let currentWord = ""
        console.log(wordGuess);
    
        yourScore ++;
        wordNum ++;
        if (wordNum > 4) {
            stillPlaying = false;
        }
        else {
            console.log("in nextWord", wordNum);
            //document.getElementById("score").value = yourScore;
            document.getElementById("word1").value = "";
            displayWord(wordNum);
        }
    


}


